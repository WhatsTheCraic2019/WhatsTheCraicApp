# Cordova-Database-Upgrade
How to upgrade database in cordova application for iOS and Android.

This example will help you to understand how you can manage the database upgradation in ios and android application in cordova phoengap.
Download this project run on simulator.


----------------------!!!!!!!!!!!!!!!------------------------!!!!!!!!!!!!!!!!!!!!-----------------------------!!!!!!!!-------------

Follow us on social media <br/>

https://facebook.com/technewsoninfologs/

https://twitter.com/webboostings/


Get more video turorials on

http://infologs.in/

https://youtube.com/webboostings/

http://webboostings.blogspot.in/


Thanks

Infologs Team
