$(document).on("ready", function(){
    databaseCreate.createDatabase();
});
function addUser(){
    var username = $("#txtUsername").val();
    var PSW = $("#txtPsw").val();
	

    if(!username && !PSW ) {
      alert("Input Fields Is Required");
   }else{
       var r = confirm("email: " + username + "\n" + "Password: " + PSW );
        if(r==true){
            loginHandler.addUser(username, PSW);
			$("#txtUsername").val("");
			$("#txtPSW").val("");
        }
    }
}