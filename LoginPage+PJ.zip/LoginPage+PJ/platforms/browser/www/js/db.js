	
		document.addEventListener("deviceready", onDeviceReady, false);
		
		function onDeviceReady() {
	alert("cordova is loaded");
												// db 			db version		display name				db size
                var database = window.openDatabase("UserDB",	 "1.0", 	"User Database",	 20000)
				
				database.transaction(populateDB, errorDB, successDB);
            }
			
			function populateDB(tx){
				tx.executeSql("CREATE TABLE IF NOT EXISTS User (RollNo INTEGER, UserID text, Password text)");
			}
			
			function errorDB(error){
				navigator.notification.alert(error, null, "Got an error", "OK");
			}
			
			function successDB(){
				navigator.notification.alert("Database is created successfully", null, "Information", "OK");
			}
			
			function registerUser (){
				var rollNo = document.getElementById("txtRollNo");
				var id = document.getElementById("txtId");
				var password = document.getElementById("txtPassword");
				
				var database = window.openDatabase("UserDB",	 "1.0", 	"User Database",	 20000);
				database.transaction(function(tx){
				NewUser(tx, RollNo, id, password);
				}, errorRegistration, SuccessRegistration);
				
			}
			
			function NewUser(tx, RollNo, id, password){
				tx.executeSql("INSERT INTO User (RollNo, UserID, Password) values("+ RollNo + ",'" + id + "','"+ password + "' )");
			}
			
			function errorRegistration(){
				navigator.notification.alert(error, null, "Got an error", "OK");
			}
			
			function SuccessRegistration(){
				navigator.notification.alert("User is registered", null, "Information", "OK");
			}
			
			
			
    