$(document).on("ready", function(){
    databaseHandler.createDatabase();
});
function addProduct(){
    var name = $("#txtName").val();
    var address = $("#txtAddress").val();
	var offers = $("#txtOffers").val();
	var description = $("#txtDes").val();

    if(!name && !address && !offers && !description) {
      alert("Input Fields Is Required");
   }else{
       var r = confirm("Name: " + name + "\n" + "Address: " + address + "\n" + "Description: " + description + "\n" + "Offers: " + offers);
        if(r==true){
            productHandler.addProduct(name, address, description, offers);
            $("#txtName").val("");
            $("#txtAddress").val("");
			$("#txtDes").val("");
			$("#txtOffers").val("");
        }
    }
}
var currentProduct={
id: -1,
name: "",
address: "",
description: "",
offers: "",
}
function displayProducts(results){
    var length = results.rows.length;
    var lstProducts = $("#lstProducts");
    lstProducts.empty();//Clean the old data before adding.
    for(var i = 0; i< length; i++){
        var item = results.rows.item(i);
        var a = $("<a />");
        var h3 = $("<h3 />").text("Business name: ");
        var h4 = $("<h4 />").text("Address: ");
		var h6 = $("<h6 />").text("Description: ");
		var h5 = $("<h5 />").text("Offers: ");
        var p = $("<p />").text("Id: ");
		
        var spanName = $("<span />").text(item.name);
        spanName.attr("name", "name");
		
        var spandAddress = $("<span />").text(item.address);
        spandAddress.attr("name", "address");
		
		var spandDescription = $("<span />").text(item.description);
        spandDescription.attr("name", "description");
		
		var spandOffer = $("<span />").text(item.offers);
        spandOffer.attr("name", "offers");
		
        var spanId = $("<span />").text(item._id);
        spanId.attr("name", "_id");
		
        h3.append(spanName);
        h4.append(spandAddress);
		h6.append(spandDescription);
		h5.append(spandOffer);
        p.append(spanId);
        a.append(h3);
        a.append(h4);
		a.append(h6);
		a.append(h5);
        a.append(p);
        var li = $("<li/>");
        li.attr("data-filtertext", item.name);
        li.append(a);
        lstProducts.append(li);
    }
    lstProducts.listview("refresh");
    lstProducts.on("tap", "li", function(){
        currentProduct.id = $(this).find("[name='_id']").text();
        currentProduct.name = $(this).find("[name='name']").text();
        currentProduct.address = $(this).find("[name='address']").text();
		currentProduct.description = $(this).find("[name='description']").text();
		currentProduct.offers = $(this).find("[name='offers']").text();
        //Set event for the list item
        $("#popupUpdateDelete").popup("open");
    });
}

$(document).on("pagebeforeshow", "#loadpage", function(){
    productHandler.loadProducts(displayProducts);
});

function deleteProduct(){
    var r = confirm("Delete advertisement\nName: "+currentProduct.name+
                    "\nAddress: " + currentProduct.address + "\nDescription: "
					+currentProduct.description + "\nOffers: " +currentProduct.offers);
    if(r==true){
        productHandler.deleteProduct(currentProduct.id);
        productHandler.loadProducts(displayProducts);
    }
    $("#popupUpdateDelete").popup("close");
}

$(document).on("pagebeforeshow", "#updatedialog", function(){
    $("#txtNewName").val(currentProduct.name);
    $("#txtNewAddress").val(currentProduct.address);
	$("#txtNewDes").val(currentProduct.description);
    $("#txtNewOffers").val(currentProduct.offers);
});

function updateProduct(){
    var newName = $("#txtNewName").val();
    var newAddress = $("#txtNewAddress").val();
	var newDescription = $("#txtNewDes").val();
	var newOffers = $("#txtNewOffers").val();
    productHandler.updateProduct(currentProduct.id, newName, newAddress, newDescription, newOffers);
    $("#updatedialog").dialog("close");
}