function checkLogin(){
	
var confirmedUsername = "admin";
var confirmedPassword = "login";

	var username = document.getElementById("username").value;
	var psw = document.getElementById("psw").value;
	if(username == confirmedUsername && psw == confirmedPassword){
		window.location="addvertisement.html";
		
	}
	else{
		alert('error');
	}
}