var loginHandler={
addUser: function(email, passwrd){
    databaseCreate.db.transaction(
        function(tx){
            tx.executeSql(
                "INSERT INTO login(email, passwrd) values(?, ?)",
                [email, passwrd],
                function(tx, results){},
                function(tx, error){
                    console.log("login error: " + error.message);
                }
            );
        },
        function(error){},
        function(){}
    );
},
};
   
