$(document).on("ready", function(){
    databaseCreate.createDatabase();
});
function addUser(){
	
	var psw = document.getElementById("RegPassword");
    var psw2 = document.getElementById("RepPassword");
	
	
    var email = $("#email").val();
    var passwrd = $("#RegPassword").val();
	

    if(!email && !passwrd ) {
      alert("Input Fields Is Required");
   }//else
	   
   
   else if(psw.value != psw2.value){
	   alert('passwords dont match');
   }
	else{
			  
			  
		   
		   
       var r = confirm("email: " + email + "\n" + "Password: " + passwrd + "\n" + "You can now sign in ");
        if(r==true){
            loginHandler.addUser(email, passwrd);
			$("#email").val("");
			$("#RegPassword").val("");
			window.location="page1.html";

        }
	}
}



var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}



/*function registerPsw(){
	
    var psw = document.getElementById("RegPassword");
    var psw2 = document.getElementById("RepPassword");
	var mail = document.getElementById("email");

	// If Password are identical AND are not empty AND mail not empty
     if(psw.value == psw2.value && psw.value.length != 0 && psw2.value.length != 0 && mail.value.length != 0){
		 window.location="page1.html"; 
	} 
	else if(psw.value != psw2.value){
		alert('passwords dont match');
	}
    else if (mail.value.length == 0){
		alert('Type in an email address');
	} 
else if(psw.value.length == 0 && psw2.value.length == 0){
	alert('Choose a password');
	}
}*/



function checkLogin(){
	
	//var currentPasswrd = $(this).find("[name='passwrd']").text();
	
	var passWord = JSON.parse(localStorage.getItem("passwrd"));
	var enteredValue = $('#passwrd').val()
	if (passWord == enteredValue) {
		alert('passwords correct');
		//console.log("value Exist!!");
					window.location="addvertisement.html";
	}
	else{
		alert('password incorrect');
	}
}

function goBack(){
	window.location="index.html";
}

function signIn(){
	window.location="page1.html";
}






