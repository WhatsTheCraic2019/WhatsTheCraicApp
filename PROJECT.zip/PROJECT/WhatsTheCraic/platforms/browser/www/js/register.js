function registerPsw(){
	
    var psw = document.getElementById("RegPassword");
    var psw2 = document.getElementById("RepPassword");
	var mail = document.getElementById("email");

	// If Password are identical AND are not empty AND mail not empty
     if(psw.value == psw2.value && psw.value.length != 0 && psw2.value.length != 0 && mail.value.length != 0){
		 window.location="page1.html"; 
	} 
	else if(psw.value != psw2.value){
		alert('passwords dont match');
	}
    else if (mail.value.length == 0){
		alert('Type in an email address');
	} 
else if(psw.value.length == 0 && psw2.value.length == 0){
	alert('Choose a password');
	}
}