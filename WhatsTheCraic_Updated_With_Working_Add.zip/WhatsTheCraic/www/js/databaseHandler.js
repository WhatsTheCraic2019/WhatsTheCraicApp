var databaseHandler = {
db: null,
createDatabase: function(){
    this.db = window.openDatabase(
        "adds.db",
        "1.0",
        "adds database",
        5000000);
    this.db.transaction(
        function(tx){
            //Run sql here using tx
            tx.executeSql(
                "create table if not exists adds(_id integer primary key, name text, address text, description text, offers text)",[],
                function(tx, results){},
                function(tx, error){
                    console.log("Error while creating the table: " + error.message);
                }
            );
        },
        function(error){
            console.log("Transaction error: " + error.message);
        },
        function(){
            console.log("Create DB transaction completed successfully");
        }
    );

}
}